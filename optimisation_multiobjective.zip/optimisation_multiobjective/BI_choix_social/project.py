# -*- coding: utf-8 -*-
import pandas as pd


class choixSocial(object):
    def __init__(self, lien):
        self.data = pd.read_csv(lien, encoding="ISO-8859-1", header=None)  # Extraction
        self.data.index += 1
        self.columns = list(self.data.index)
        self.data_unique = self._get_occurence_classement()

        print("Classements : \n", self.data_unique, "\n")

    def _get_occurence_classement(self):
        data_unique = self.data.T.drop_duplicates().T  # Retourne les classement

        num_classement = []  # Liste contenant le nombre d'occurence pour chaque classement
        print("Nombre de classements disponible : ", data_unique.shape[1])
        data_unique = data_unique.T  # Transposé

        for feature in self.data.T.groupby(self.columns).groups.values():
            data_unique.loc[feature[0], "number"] = feature.shape[0]
            num_classement.append(feature.shape[0])

        # Trie decroissant des classement par rapport au nombre
        data_unique = data_unique.sort_values(by=["number"], ascending=False)

        return data_unique

    def un_tour(self):
        print("---------------------- Un tour ------------------------")
        classement = pd.DataFrame(columns=["condidat", "points"])

        for col in self.columns:
            group = self.data_unique.groupby([col])['number'].agg('sum')
            if 1 == group.index[0]:
                classement.loc[col, :] = [col, group.iloc[0]]
            else:
                classement.loc[col, :] = [col, 0]

        classement.sort_values(by=["points"], ascending=False, inplace=True, ignore_index=True)

        print("Le classement avec la méthode à un tour : ")
        print(classement, "\n")

        print("Le gagnant est donc le condidat n°: ", classement.iloc[0]["condidat"], " avec : ",
              classement.iloc[0]['points'], " points\n")

    def deux_tours(self):
        print("---------------------- Deux tours ------------------------")
        classement = pd.DataFrame(columns=["condidat", "points"])

        for col in self.columns:
            group = self.data_unique.groupby([col])['number'].agg('sum')
            if 1 == group.index[0]:
                classement.loc[col, :] = [col, group.iloc[0]]
            else:
                classement.loc[col, :] = [col, 0]

        classement.sort_values(by=["points"], ascending=False, inplace=True, ignore_index=True)

        first_condidat = classement.iloc[0]['condidat']  # Condidat ayant la première place durant le premier tour
        second_condidat = classement.iloc[1]["condidat"]  # Condidat ayant la deuxième place durant le premier tour

        # Nombre de vote pour le premier condidat
        for_first = self.data_unique.loc[
            self.data_unique[first_condidat] < self.data_unique[second_condidat], "number"].agg(
            'sum')

        # Nombre de vote pour le deuxième condidat
        for_second = self.data.shape[1] - for_first  # Nombre de vote total - nombre de vote pour le premier condidat

        print("Le classement avec la méthode à deux tours : ")
        if for_first > for_second:
            print("Le gagnant est donc le condidat n°: ", first_condidat, " avec : ", for_first, " le deuxième est donc"
                                                                                                 " le condidat n°",
                  second_condidat, " avec : ", for_second, "\n")
        else:
            print("Le gagnant est donc le condidat n°: ", second_condidat, " avec : ", for_second, "le deuxième est "
                                                                                                   "donc le condidat n",
                  first_condidat, " avec : ", for_first, "\n")

    def borda(self):
        print("---------------------- Borda ------------------------")
        classement = pd.DataFrame(columns=["condidat", "points"])

        # Pour chaque colonne regrouper par position dans classement, faire la somme pour chaque position,
        # puis multilipier par les poids
        """
            1- 
                Exemple : 
                    1: 
                        * 10
                        * 20
                    2: 
                        * 5
                        * 6

                la somme va donner :    
                    1: 30
                    2: 11

            2- Mutliplication par les poids 
                2*30 + 1*11 

        """
        for col in self.columns:
            group = self.data_unique.groupby([col])['number'].agg('sum')
            group.index = len(self.columns) - group.index + 1
            classement.loc[col, :] = [col, group.multiply(group.index).agg('sum')]

        # Je fais un tri descandant, du plus grand vers le plus petit 
        classement.sort_values(by=["points"], ascending=False, inplace=True, ignore_index=True)

        print("Le classement avec la méthode Borda : ")
        print(classement, "\n")

        if classement.iloc[0]["points"] == classement.iloc[1]["points"]:
            print("Cas d'égalité pour Borda, donc aucun condidat ne gagne pour Borda")
        else:
            # Je récupère celui à la première place
            print("Le gagnant est donc le condidat n°: ", classement.iloc[0]["condidat"], " avec : ",
                  classement.iloc[0]['points'], " points\n")

    def condorcet(self):
        print("------------------- condorcet ---------------------")
        condorcet = pd.DataFrame(columns=self.columns)

        # Calcule duel pour chaque condidat
        for i in range(1, len(self.columns) + 1):
            for j in range(i + 1, len(self.columns) + 1):
                for_first = self.data_unique.loc[
                    self.data_unique[i] < self.data_unique[j], "number"].agg('sum')

                # Nombre de vote total - nombre de vote pour le premier condidat
                for_second = self.data.shape[1] - for_first

                condorcet.loc[i, j] = for_first
                condorcet.loc[j, i] = for_second

        print("Le tableau des duels : ")
        print(condorcet, "\n")

        gagnant = False
        for i in range(1, len(self.columns) + 1):
            mask = condorcet[i] < condorcet.loc[i, :]
            if mask[mask == True].shape[0] == len(self.columns) - 1:
                print("Le gagnant est donc le condidat n°: ", i, "\n")
                gagnant = True

        if not gagnant:
            print("Aucun gagnant avec condorcet, donc voir avec la méthode min-max et copland\n")

            def min_max():
                print("--------------------- Min Max --------------------")
                print("Minimax sélectionne comme vainqueur le candidat dont la plus grande défaite par paire est "
                      "inférieure à la plus grande défaite par paire de tout autre candidat \n")

                classement = pd.DataFrame(data={"condidat": self.columns, "points": condorcet.max(axis=0).values})
                classement.sort_values(by=["points"], ascending=True, inplace=True, ignore_index=True)

                print("Le classement avec la méthode min_max : ")
                print(classement, "\n")

                if classement.iloc[0]["points"] == classement.iloc[1]["points"]:
                    print("Cas d'égalité pour MinMax, donc aucun condidat ne gagne pour MinMax")
                else:
                    print("Le gagnant avec la méthode min-max est donc le condidat n°: ", classement.iloc[0]["condidat"]
                          , " avec : ", classement.iloc[0]['points'], " points de la plus grosse perte\n")

            def copland():
                print("--------------------- Copland --------------------")
                print("Copland calcule pour chaque condidat le nombre de paur gagné - le nombre de pair perdu et "
                      "choisi le meilleur score \n")

                classement = pd.DataFrame(columns=["condidat", "points"], data={"condidat": self.columns})

                for i in range(1, len(self.columns) + 1):
                    mask = condorcet[i] < condorcet.loc[i, :]
                    classement.loc[i - 1, "points"] = mask[mask == True].shape[0] - (mask[mask == False].shape[0] - 1)

                classement.sort_values(by=["points"], ascending=False, inplace=True, ignore_index=True)

                print("Le classement avec la méthode min_max : ")
                print(classement, "\n")

                if classement.iloc[0]["points"] == classement.iloc[1]["points"]:
                    print("Cas d'égalité pour Copland, donc aucun condidat ne gagne pour Copland")
                else:
                    print("Le gagnant avec la méthode copland est donc le condidat n°: ", classement.iloc[0]["condidat"]
                          , " avec : ", classement.iloc[0]['points'], " points\n")

            min_max()
            copland()

    def coombs(self):
        print("------------------ Coombs ------------------")
        print("Méthode Coombs supprime le condidat qui est le plus souvent dernier d'un classement\n")
        data = self.data_unique.copy()
        classement = None
        columns = self.columns.copy()

        while len(columns) != 1:
            classement = pd.DataFrame(columns=["condidat", "points"])

            for col in columns:
                group = data.groupby([col])['number'].agg('sum')

                # Il faut qu'il soit dernier de la liste au moins une fois
                if len(columns) == group.index[-1]:
                    classement.loc[col, :] = [col, group.iloc[-1]]

            classement.sort_values(by=["points"], ascending=False, inplace=True, ignore_index=True)
            data[data[columns].apply(lambda row: row > row[classement.iloc[0]["condidat"]], axis=1)] -= 1

            columns.remove(classement.iloc[0]["condidat"])

        print("Le gagnant est donc le condidat n°: ", classement.iloc[-1]["condidat"], " avec : ",
              classement.iloc[-1]["points"], " points\n")

    def alternatif(self):
        print("------------------ Alternatif ------------------")
        print("Méthode Alternatif supprime le condidat qui est le plus mois souvent premier d'un classement\n")
        data = self.data_unique.copy()
        classement = None
        columns = self.columns.copy()

        while len(columns) != 1:
            classement = pd.DataFrame(columns=["condidat", "points"])
            for col in columns:
                group = data.groupby([col])['number'].agg('sum')

                # Il faut qu'il soit de la liste au moins une fois
                if 1 == group.index[0]:
                    classement.loc[col, :] = [col, group.iloc[0]]
                else:
                    classement.loc[col, :] = [col, 0]

            classement.sort_values(by=["points"], ascending=True, inplace=True, ignore_index=True)

            data[data[columns].apply(lambda row: row > row[classement.iloc[0]["condidat"]], axis=1)] -= 1
            columns.remove(classement.iloc[0]["condidat"])

        print("Le gagnant est donc le condidat n°: ", classement.iloc[-1]["condidat"], " avec : ",
              classement.iloc[-1]["points"], " points\n")


if __name__ == '__main__':
    social = choixSocial("data/profil1.csv")
    social.un_tour()
    social.deux_tours()
    social.borda()
    social.condorcet()
    social.coombs()
    social.alternatif()
